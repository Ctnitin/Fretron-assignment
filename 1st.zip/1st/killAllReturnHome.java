import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class killAllReturnHome{
    static int cnt = 0;
    static List<List<int[]>> paths = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        cnt = 0;
        paths.clear();
        int size = 9;
        int[][] chessboard = new int[size][size];

        System.out.print("Enter number of soldiers: ");
        int soldierCount = Integer.parseInt(scanner.nextLine());

       
        for (int i = 1; i <= soldierCount; i++) {
            System.out.print("Enter coordinates for soldier " + i + " (format: x,y): ");
            String[] coords = scanner.nextLine().split(",");
            int x = Integer.parseInt(coords[0]) - 1; 
            int y = Integer.parseInt(coords[1]) - 1; 
            
            if (x >= 0 && x < size && y >= 0 && y < size) {
                chessboard[y][x] = 1; 
            } else {
                System.out.println("Invalid coordinates. Please enter values between 1 and " + size);
                i--; 
            }
        }

        // printChessboard(chessboard);

        System.out.print("Enter the coordinates for your special castle (format: x,y): ");
        String[] coords = scanner.nextLine().split(",");
        int startX = Integer.parseInt(coords[0]) - 1; 
        int startY = Integer.parseInt(coords[1]) - 1;

        int[][] vis = new int[size][size];

        List<int[]> initialPath = new ArrayList<>();
        initialPath.add(new int[]{startX, startY});
        solve(chessboard, vis, startY, startX, startY, startX, 'd', 0, initialPath);

        System.out.println("Total unique paths: " + cnt);
        // printPaths();
        scanner.close();
    }

    private static void printChessboard(int[][] chessboard) {
        System.out.println("Chessboard:");
        for (int[] row : chessboard) {
            for (int cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    // private static void printPaths() {
    //     for (int i = 0; i < paths.size(); i++) {
    //         System.out.println("Path " + (i + 1) + ":");
    //         for (int[] step : paths.get(i)) {
    //             System.out.print("(" + (step[0] + 1) + "," + (step[1] + 1) + ") ");
    //         }
    //         System.out.println("\n" + "=".repeat(10));
    //     }
    // }

    static void solve(int[][] mat, int[][] vis, int row, int col, int r, int c, char dir, int pathLength, List<int[]> path) {
        int size = mat.length;

        if (row < 0 || col < 0 || row >= size || col >= size) {
            return;
        }

        
        if (row == r && col == c && pathLength > 0) {
            cnt++;
            paths.add(new ArrayList<>(path));
            return;
        }

        if (mat[row][col] == 1) {
            if (vis[row][col] != 1) {
                vis[row][col] = 1; 

               
                switch (dir) {
                    case 'd': 
                        solve(mat, vis, row, col + 1, r, c, 'r', pathLength + 1, addToPath(path, row, col + 1)); // Move right
                        break;
                    case 'r': 
                        solve(mat, vis, row - 1, col, r, c, 'u', pathLength + 1, addToPath(path, row - 1, col)); // Move up
                        break;
                    case 'u': 
                        solve(mat, vis, row, col - 1, r, c, 'l', pathLength + 1, addToPath(path, row, col - 1)); // Move left
                        break;
                    case 'l': 
                        solve(mat, vis, row + 1, col, r, c, 'd', pathLength + 1, addToPath(path, row + 1, col)); // Move down
                        break;
                }

               
                vis[row][col] = 0;
            }

            
            switch (dir) {
                case 'd':
                    solve(mat, vis, row + 1, col, r, c, dir, pathLength, addToPath(path, row + 1, col));
                    break;
                case 'r':
                    solve(mat, vis, row, col + 1, r, c, dir, pathLength, addToPath(path, row, col + 1)); 
                    break;
                case 'u':
                    solve(mat, vis, row - 1, col, r, c, dir, pathLength, addToPath(path, row - 1, col)); 
                    break;
                case 'l':
                    solve(mat, vis, row, col - 1, r, c, dir, pathLength, addToPath(path, row, col - 1)); 
                    break;
            }
        } else {
            switch (dir) {
                case 'd':
                    solve(mat, vis, row + 1, col, r, c, dir, pathLength, addToPath(path, row + 1, col)); 
                    break;
                case 'r':
                    solve(mat, vis, row, col + 1, r, c, dir, pathLength, addToPath(path, row, col + 1)); 
                    break;
                case 'u':
                    solve(mat, vis, row - 1, col, r, c, dir, pathLength, addToPath(path, row - 1, col));
                    break;
                case 'l':
                    solve(mat, vis, row, col - 1, r, c, dir, pathLength, addToPath(path, row, col - 1)); 
                    break;
            }
        }
    }

    private static List<int[]> addToPath(List<int[]> path, int row, int col) {
        List<int[]> newPath = new ArrayList<>(path);
        newPath.add(new int[]{row, col});
        return newPath;
    }
}