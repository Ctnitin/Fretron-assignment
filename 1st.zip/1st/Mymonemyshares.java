import java.util.*;

class Mymoneymyshares {
    static class Individual {
        String name;
        List<Integer> weights;
        int targetWeight;
        int currentWeight;

        Individual(String name, int targetWeight) {
            this.name = name;
            this.weights = new ArrayList<>();
            this.targetWeight = targetWeight;
            this.currentWeight = 0;
        }

        void addWeight(int weight) {
            weights.add(weight);
            currentWeight += weight;
        }

        void removeWeight(int weight) {
            weights.remove(Integer.valueOf(weight));
            currentWeight -= weight;
        }

        @Override
        public String toString() {
            return name + ": " + weights + " (Total: " + currentWeight + "g)";
        }
    }

    static List<List<Integer>> bestAllocation = new ArrayList<>();
    static int minDifference = Integer.MAX_VALUE;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> fruitWeights = new ArrayList<>();

        System.out.println("Enter fruit weight in grams (-1 to stop): ");
        while (true) {
            int weight = scanner.nextInt();
            if (weight == -1) {
                break;
            }
            fruitWeights.add(weight);
        }

        int totalAmount = 100; 
        int paymentA = 50;
        int paymentB = 30;
        int paymentC = 20;

        int totalWeight = fruitWeights.stream().mapToInt(Integer::intValue).sum();
        Individual personA = new Individual("A", (paymentA * totalWeight) / totalAmount);
        Individual personB = new Individual("B", (paymentB * totalWeight) / totalAmount);
        Individual personC = new Individual("C", (paymentC * totalWeight) / totalAmount);

        allocateFruits(fruitWeights, 0, personA, personB, personC);

        System.out.println("Best Allocation Result:");
        System.out.println("A: " + bestAllocation.get(0));
        System.out.println("B: " + bestAllocation.get(1));
        System.out.println("C: " + bestAllocation.get(2));
    }

    static void allocateFruits(List<Integer> fruitWeights, int index, Individual personA, Individual personB, Individual personC) {
        if (index == fruitWeights.size()) {
            int totalWeight = personA.currentWeight + personB.currentWeight + personC.currentWeight;
            int difference = Math.abs(totalWeight - (personA.targetWeight + personB.targetWeight + personC.targetWeight));
            
            if (difference < minDifference) {
                minDifference = difference;
                bestAllocation.clear();
                bestAllocation.add(new ArrayList<>(personA.weights));
                bestAllocation.add(new ArrayList<>(personB.weights));
                bestAllocation.add(new ArrayList<>(personC.weights));
            }
            return;
        }

        int weight = fruitWeights.get(index);

        if (personA.currentWeight + weight <= personA.targetWeight) {
            personA.addWeight(weight);
            allocateFruits(fruitWeights, index + 1, personA, personB, personC);
            personA.removeWeight(weight);
        }

        if (personB.currentWeight + weight <= personB.targetWeight) {
            personB.addWeight(weight);
            allocateFruits(fruitWeights, index + 1, personA, personB, personC);
            personB.removeWeight(weight);
        }

        if (personC.currentWeight + weight <= personC.targetWeight) {
            personC.addWeight(weight);
            allocateFruits(fruitWeights, index + 1, personA, personB, personC);
            personC.removeWeight(weight);
        }

        allocateFruits(fruitWeights, index + 1, personA, personB, personC);
    }
}
